package elizagn.functions.base;

import java.util.List;
import java.util.Map;

import elizagn.interfaces.IExpression;

public abstract class Function implements IExpression {
    private final List<IExpression> _expressions;
    protected List<Double> args;
    private Map<String, Double> vars;
    private Double cache = null;

    protected Function(List<IExpression> expressions) {
        _expressions = expressions;
    }

    protected abstract double evaluate();

    public List<IExpression> getExpressions() {
        return _expressions;
    }

    @Override
    public double evaluate(Map<String, Double> variables) {
        if (cache != null) {
            return cache;
        }

        vars = variables;
        args = _expressions.stream()
                .map(arg -> arg.evaluate(vars))
                .toList();
        cache = evaluate();

        return cache;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (!(o instanceof Function function))
            return false;

        return _expressions.equals(function._expressions);
    } // для сравнения функции

    @Override
    public int hashCode() {
        return _expressions.hashCode();
    }

    @Override
    public String toString() {
        return String.valueOf(_expressions);
    }
}