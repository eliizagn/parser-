package elizagn.interfaces;

public interface IValue extends IExpression {
}
